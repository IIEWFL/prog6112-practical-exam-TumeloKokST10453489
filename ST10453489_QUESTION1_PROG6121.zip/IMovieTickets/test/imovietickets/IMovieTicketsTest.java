/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package imovietickets;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class IMovieTicketsTest {

    // Test for the TotalMoviesSales method
    @Test
    public void CalculateTotalSales_ReturnExpectedTotalSales() {
        // Arrange
        MovieTickets movieTicket = new MovieTickets();
        int[] movieTicketSales = {3000, 1500, 1700};  // Sales for 3 months
        
        // Act
        int totalSales = movieTicket.TotalMoviesSales(movieTicketSales);
        
        // Assert
        int expectedTotal = 3000 + 1500 + 1700;  // Expected total sales = 6200
        assertEquals(expectedTotal, totalSales, "The total movie sales should be 6200");
    }

    // Test for the TopMovie method
    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Arrange
        MovieTickets movieTicket = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6400};  // Total sales for both movies
        
        // Act
        String topMovie = movieTicket.TopMovie(movies, totalSales);
        
        // Assert
        String expectedTopMovie = "Oppenheimer";  // Oppenheimer has the highest sales
        assertEquals(expectedTopMovie, topMovie, "The top movie should be Oppenheimer");
    }
}
