/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package imovietickets;

import java.util.Arrays;

   public interface IMovieTickets {
    int TotalMoviesSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}

// Implement the MovieTickets class, which provides the required functionality
class MovieTickets implements IMovieTickets {

    // Method to calculate the total ticket sales for a single movie
    @Override
    public int TotalMoviesSales(int[] movieTicketSales) {
        return Arrays.stream(movieTicketSales).sum();
    }

    // Method to find the top-performing movie based on total sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        String topMovie = movies[0];
        // Loop through total sales to find the movie with the highest sales
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }
        return topMovie;
    }

    // Static method to generate a formatted report displaying movie sales data
    public static void generateReport(String[] movies, int[][] salesData) {
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println();
        
        // Print the header with the months
        System.out.printf("%-20s %10s %10s %10s%n", "", "Jan", "Feb", "March");
        System.out.println("-------------------------------------------------------");

        // Instantiate MovieTickets to use its methods for each movie's total sales
        MovieTickets movieTicket = new MovieTickets();
        int[] totalSales = new int[movies.length];

        // Loop through each movie and display monthly sales
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-20s %10d %10d %10d%n", movies[i], salesData[i][0], salesData[i][1], salesData[i][2]);
            // Calculate total sales for each movie
            totalSales[i] = movieTicket.TotalMoviesSales(salesData[i]);
        }
        System.out.println();

        // Display the total sales for each movie
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("Total movie ticket sales for %s: %d%n", movies[i].toLowerCase(), totalSales[i]);
        }
        System.out.println();

        // Determine the top-performing movie and display it
        String topMovie = movieTicket.TopMovie(movies, totalSales);
        System.out.printf("Top Performing movie: %s%n", topMovie);
    }
}

// Main class to run the application and generate the report
 class MovieApp {
    public static void main(String[] args) {
        // Define movies and their monthly sales data
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] salesData = {
            {3000, 1500, 1700},  // Napoleon sales for Jan, Feb, March
            {3500, 1200, 1600}   // Oppenheimer sales for Jan, Feb, March
        };

        // Generate and display the report in the specified format
        MovieTickets.generateReport(movies, salesData);
    }
}

