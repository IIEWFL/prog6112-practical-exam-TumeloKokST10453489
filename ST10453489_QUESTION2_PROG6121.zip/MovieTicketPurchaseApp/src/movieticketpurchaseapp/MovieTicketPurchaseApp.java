/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketpurchaseapp;  // Package declaration for organizing classes

// Import necessary libraries for creating a graphical user interface (GUI) and handling events
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

// This is the Interface for movie ticket operations defining methods for calculating price and validating data
public interface IMovieTickets {
    double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean validateData(MovieTicketData movieTicketData);
}

// This Class is to hold movie ticket data 
class MovieTicketData {
    private String movieName; // This is for the Movie name
    private double ticketPrice; // This is for the Ticket price
    private int numberOfTickets; // This is for the Number of tickets

    // This is a Constructor to initialize movie ticket data
    public MovieTicketData(String movieName, double ticketPrice, int numberOfTickets) {
        this.movieName = movieName;
        this.ticketPrice = ticketPrice;
        this.numberOfTickets = numberOfTickets;
    }

    // These are Getter methods for accessing private variables
    public String getMovieName() {
        return movieName;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }
}

// This is the Class for implementing the IMovieTickets interface that will provide the logic for ticket operations
class MovieTickets implements IMovieTickets {
    @Override
    public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        final double VAT_RATE = 0.14; // This is the 14% VAT rate 
        return numberOfTickets * ticketPrice * (1 + VAT_RATE); // This will Calculate the total price including VAT
    }

    @Override
    public boolean validateData(MovieTicketData movieTicketData) {
        // This Validates that the movie name is not null or empty
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().isEmpty()) {
            return false;
        }
        // This Validates that the ticket price is greater than 0
        if (movieTicketData.getTicketPrice() <= 0) {
            return false;
        }
        // This Validates that the number of tickets is greater than 0
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false;
        }
        return true; // will return true if the Data is valid
    }
}

//This is the Main class to create the movie ticket purchase application with a Swing GUI
public class MovieTicketPurchaseApp {
    public static void main(String[] args) {
        // This will Create the main frame for the application
        JFrame frame = new JFrame("MOVIE TICKETS");
        frame.setSize(500, 400); //This will Set the size of the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // This will Close the operation for the window
        frame.setLayout(new FlowLayout()); // This will Set the layout manager

        // This will Create labels, combo box, and text fields for user input
        JLabel movieLabel = new JLabel("Movie:");
        JComboBox<String> movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"}); // Dropdown for movies

        JLabel ticketPriceLabel = new JLabel("Ticket Price:");
        JTextField ticketPriceField = new JTextField(10); // This is the Field for entering ticket price

        JLabel numOfTicketsLabel = new JLabel("Number of Tickets:");
        JTextField numOfTicketsField = new JTextField(10); // This is the Field for entering number of tickets

        // Text area to display report output
        JTextArea reportArea = new JTextArea(10, 40);
        reportArea.setEditable(false); // This will Make the text area read-only
        JScrollPane scrollPane = new JScrollPane(reportArea); // This is the Add scroll function

        // The Buttons for processing and clearing data
        JButton processButton = new JButton("Process");
        JButton clearButton = new JButton("Clear");

        // This will Create a menu bar with "File" and "Tools" menus
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        fileMenu.add(exitItem); // This will Add the "Exit" menu item to the "File" menu
        menuBar.add(fileMenu); // This will Add the "File" menu to the menu bar

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        toolsMenu.add(processMenuItem); // This will Add the "Process" menu item
        toolsMenu.add(clearMenuItem); // This will Add the "Clear" menu item
        menuBar.add(toolsMenu); // This will Add the "Tools" menu to the menu bar

        frame.setJMenuBar(menuBar); // responsible for Setting the menu bar for the frame

        // responsible for Adding the components to the frame for the user interface
        frame.add(movieLabel);
        frame.add(movieComboBox);
        frame.add(ticketPriceLabel);
        frame.add(ticketPriceField);
        frame.add(numOfTicketsLabel);
        frame.add(numOfTicketsField);
        frame.add(processButton);
        frame.add(clearButton);
        frame.add(scrollPane);

        frame.setVisible(true); // Make the frame visible

        // This is the ActionListener for the "Process" button and menu item
        ActionListener processAction = e -> {
            // This will Retrieve the user input
            String movieName = (String) movieComboBox.getSelectedItem();
            double ticketPrice;
            int numberOfTickets;

            // is responsible for Validating and parse user input
            try {
                ticketPrice = Double.parseDouble(ticketPriceField.getText());
                numberOfTickets = Integer.parseInt(numOfTicketsField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid numbers."); // Error message will display if users enters an invalid input
                return;
            }

            // This will Create a MovieTicketData object with the user input
            MovieTicketData movieTicketData = new MovieTicketData(movieName, ticketPrice, numberOfTickets);
            MovieTickets movieTickets = new MovieTickets();

            // Responsible for Validating the data using the MovieTickets class
            if (!movieTickets.validateData(movieTicketData)) {
                JOptionPane.showMessageDialog(frame, "Movie Ticket can not be less than or equal to zero, Please try again"); // Validation error
                return;
            }

            // This will Calculate the total ticket price and display the report
            double totalPrice = movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);
            reportArea.setText("MOVIE TICKET REPORT\n" +
                    "*************************\n" +
                    "MOVIE NAME: " + movieName + "\n" +
                    "MOVIE TICKET PRICE: R " + ticketPrice + "\n" +
                    "NUMBER OF TICKETS: " + numberOfTickets + "\n" +
                    "TOTAL TICKET PRICE: R " + String.format("%.2f", totalPrice) + "\n" +
                    "*************************");

            // will Save the report to a file
            try (FileWriter writer = new FileWriter("report.txt")) {
                writer.write(reportArea.getText());
            } catch (IOException ioException) {
                JOptionPane.showMessageDialog(frame, "Error saving report."); // Error message if file save fails
            }
        };

        // will Attach the action listener to "Process" button and the menu item
        processButton.addActionListener(processAction);
        processMenuItem.addActionListener(processAction);

        // this is a ActionListener for the "Clear" button and menu item to reset input fields and text area
        ActionListener clearAction = e -> {
            ticketPriceField.setText(""); // Clear ticket price field
            numOfTicketsField.setText(""); // Clear number of tickets field
            reportArea.setText(""); // Clear report area
        };

        // tis will Attach the action listener to the "Clear" button and the menu item
        clearButton.addActionListener(clearAction);
        clearMenuItem.addActionListener(clearAction);

        // this is a ActionListener for the "Exit" menu item to close the application
        exitItem.addActionListener(e -> System.exit(0)); // This Closes the application when the "Exit" is clicked
    }
}
