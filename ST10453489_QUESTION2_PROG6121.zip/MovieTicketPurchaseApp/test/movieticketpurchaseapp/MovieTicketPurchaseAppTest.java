package movieticketpurchaseapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Test class for MovieTickets
public class MovieTicketPurchaseAppTest {

    private MovieTickets movieTickets;

    @BeforeEach
    public void setUp() {
        // Initialize the MovieTickets object before each test
        movieTickets = new MovieTickets();
    }

    // Unit test for calculating total ticket price
    @Test
    public void testCalculateTotalPrice_CalculatedSuccessfully() {
        int numberOfTickets = 3;
        double ticketPrice = 100.0;

        // Expected result including 14% VAT
        double expectedTotalPrice = numberOfTickets * ticketPrice * 1.14;

        // Assert that the calculated total matches the expected result
        assertEquals(expectedTotalPrice, movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice), 0.01, "Total price should be calculated correctly with VAT");
    }

    // Unit test for validation: movie name is not valid (null or empty)
    @Test
    public void testValidateData_MovieNameInvalid() {
        MovieTicketData movieTicketData = new MovieTicketData("", 100.0, 2);
        assertFalse(movieTickets.validateData(movieTicketData), "Validation should fail for an empty movie name");

        MovieTicketData movieTicketDataNull = new MovieTicketData(null, 100.0, 2);
        assertFalse(movieTickets.validateData(movieTicketDataNull), "Validation should fail for a null movie name");
    }

    // Unit test for validation: ticket price is not valid (less than or equal to zero)
    @Test
    public void testValidateData_TicketPriceInvalid() {
        MovieTicketData movieTicketData = new MovieTicketData("Napoleon", -50.0, 2);
        assertFalse(movieTickets.validateData(movieTicketData), "Validation should fail for a ticket price less than or equal to zero");

        MovieTicketData movieTicketDataZero = new MovieTicketData("Napoleon", 0.0, 2);
        assertFalse(movieTickets.validateData(movieTicketDataZero), "Validation should fail for a ticket price of zero");
    }

    // Unit test for validation: number of tickets is not valid (less than or equal to zero)
    @Test
    public void testValidateData_NumberOfTicketsInvalid() {
        MovieTicketData movieTicketData = new MovieTicketData("Napoleon", 100.0, -1);
        assertFalse(movieTickets.validateData(movieTicketData), "Validation should fail for a number of tickets less than or equal to zero");

        MovieTicketData movieTicketDataZero = new MovieTicketData("Napoleon", 100.0, 0);
        assertFalse(movieTickets.validateData(movieTicketDataZero), "Validation should fail for a number of tickets equal to zero");
    }

    // Unit test for validation: all data is valid
    @Test
    public void testValidateData_AllDataValid() {
        MovieTicketData movieTicketData = new MovieTicketData("Napoleon", 100.0, 3);
        assertTrue(movieTickets.validateData(movieTicketData), "Validation should pass for valid movie name, ticket price, and number of tickets");
    }
}
